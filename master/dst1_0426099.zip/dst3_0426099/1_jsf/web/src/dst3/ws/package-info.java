@javax.xml.bind.annotation.XmlSchema(namespace = "http://ejb.dst3/")
package dst3.ws;
