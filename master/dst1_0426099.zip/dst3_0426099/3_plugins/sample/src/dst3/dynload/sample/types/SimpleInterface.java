package dst3.dynload.sample.types;

public interface SimpleInterface {
	void fooBar();
}
