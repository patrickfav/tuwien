package dst3.dynload.sample.types;

public class ClassWithOutSimpleConstructor {
	private long number;
	
	public ClassWithOutSimpleConstructor(long number) {
		this.number = number;
	}
}
