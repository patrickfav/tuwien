package dst3.dynload.sample;

public class SomeClass {
	
}
