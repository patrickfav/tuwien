package dst3;

import dst3.depinj.sample.ControllerWithInjectionsPrototype;
import dst3.depinj.sample.ControllerWithInjectionsSingelton;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("\nProtoype Components: ");
		
		ControllerWithInjectionsPrototype.taskA();
		ControllerWithInjectionsPrototype.taskA();
		ControllerWithInjectionsPrototype.taskA();
		
		System.out.println("\nSingelton Components:");
		
		ControllerWithInjectionsSingelton.taskA();
		ControllerWithInjectionsSingelton.taskA();
		ControllerWithInjectionsSingelton.taskA();
	}

}
