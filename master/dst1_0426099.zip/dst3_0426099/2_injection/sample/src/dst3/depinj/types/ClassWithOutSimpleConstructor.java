package dst3.depinj.types;

public class ClassWithOutSimpleConstructor {
	private long number;
	
	public ClassWithOutSimpleConstructor(long number) {
		this.number = number;
	}
}
