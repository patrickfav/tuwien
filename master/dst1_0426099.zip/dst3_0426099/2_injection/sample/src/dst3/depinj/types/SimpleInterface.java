package dst3.depinj.types;

public interface SimpleInterface {
	void fooBar();
}
