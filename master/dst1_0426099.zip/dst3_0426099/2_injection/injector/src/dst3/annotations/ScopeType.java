package dst3.annotations;

public class ScopeType {
	public static final int PROTOTYPE = 0;
	public static final int SINGELTON = 1;
}
