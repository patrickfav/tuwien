package dst2.ejb.interfaces;

import javax.ejb.Remote;

@Remote
public interface Testing {
	public void insertTestData();
}
