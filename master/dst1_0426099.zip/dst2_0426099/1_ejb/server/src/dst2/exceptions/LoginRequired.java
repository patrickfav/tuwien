package dst2.exceptions;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class LoginRequired extends Exception{

	private static final long serialVersionUID = 7747763955855177342L;
	
	public LoginRequired() {
		super();
	}
	public LoginRequired(String msg) {
		super(msg);
	}
	public LoginRequired(String msg,Throwable cause) {
		super(msg,cause);
	}

}